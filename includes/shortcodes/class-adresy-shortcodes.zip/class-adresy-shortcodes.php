<?php
class Adresy_Shortcodes
{
    public static function init()
    {
        require_once ADRESY_PATH . 'includes/components/modal/class-wc-default-location.php';
        add_shortcode('adresy_location_trigger', [__CLASS__, 'location_trigger']);
    }

    public static function location_trigger()
    {
        ob_start();
        $default_location = new WC_Default_Location();
        $meta_shipping = false;
        $adresy_state = '';
        $adresy_country = '';
        $settings = get_option('adresy_settings', []);
        $mode_desktop = $settings['mode_desktop'] ?? 'dark';
        $mode_mobile = $settings['mode_mobile'] ?? 'dark';


        if (is_user_logged_in()) {
            $meta_state = get_user_meta(get_current_user_id(), 'adresy_customer_state', true);
            $meta_country = get_user_meta(get_current_user_id(), 'adresy_customer_country', true);
            $meta_shipping = get_user_meta(get_current_user_id(), 'adresy_shipping_selected');
            if (!empty($meta_state)) {
                $adresy_state = sanitize_text_field($meta_state);
            }
            if (!empty($meta_country)) {
                $adresy_country = sanitize_text_field($meta_country);
            }
            $user_id = get_current_user_id();
            $shipping_first_name = get_user_meta($user_id, 'shipping_first_name', true);
            $shipping_last_name  = get_user_meta($user_id, 'shipping_last_name', true);
            $shipping_state_code = get_user_meta($user_id, 'shipping_state', true);
            $shipping_city       = get_user_meta($user_id, 'shipping_city', true);
            $shipping_address_1  = get_user_meta($user_id, 'shipping_address_1', true);
            $shipping_country_code = get_user_meta($user_id, 'shipping_country', true);

            $wc_countries = WC()->countries;
            $all_states = $wc_countries->get_states();

            $shipping_state = isset($all_states[$shipping_country_code][$shipping_state_code])
                ? $all_states[$shipping_country_code][$shipping_state_code]
                : $shipping_state_code;
        }

        if (empty($adresy_state) && isset($_COOKIE['adresy_customer_state'])) {
            $adresy_state = sanitize_text_field($_COOKIE['adresy_customer_state']);
        }
        if (empty($adresy_country) && isset($_COOKIE['adresy_customer_country'])) {
            $adresy_country = sanitize_text_field($_COOKIE['adresy_customer_country']);
        }

        $locations = '';
        if (!empty($adresy_state)) {
            $states = $default_location->get_state();
            $locations = $states[$adresy_state] ?? $adresy_state;
            $line1 = '';
        } elseif (!empty($adresy_country)) {
            if (class_exists('WC_Countries')) {
                $wc_countries = new WC_Countries();
                $countries = $wc_countries->countries;
                $locations = $countries[$adresy_country] ?? $adresy_country;
            } else {
                $locations = $adresy_country;
            }
            $line1 = '';
        } elseif ($meta_shipping == true) {
                $line1 = $shipping_first_name ? $shipping_first_name : $shipping_last_name;
                $locations = $shipping_state . ',' . $shipping_city . ',' . $shipping_address_1;
        }


        // if (defined('WP_DEBUG') && WP_DEBUG) {
        //     error_log('Adresy Country: ' . print_r($adresy_country, true));
        //     error_log('Adresy Location: ' . print_r($locations, true));
        // }

?>
            <div class="adresy-location-trigger mode-desktop-<?php echo esc_attr($mode_desktop); ?> mode-mobile-<?php echo esc_attr($mode_mobile); ?>">
            <div id="adresy-modal-label" class="adresy-open-modal">
                <div class="adresy-modal-ingress-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="20" height="20" viewBox="0 0 256 256" xml:space="preserve">
                        <g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;" transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)">
                            <path class="adresy-icon-path" d="M 45.229 90.18 l -26.97 -31.765 c -5.419 -6.387 -8.404 -14.506 -8.404 -22.861 c 0 -19.506 15.869 -35.374 35.374 -35.374 s 35.375 15.869 35.375 35.374 c 0 8.355 -2.985 16.474 -8.405 22.861 L 45.229 90.18 z M 45.229 3.121 c -17.884 0 -32.433 14.549 -32.433 32.433 c 0 7.659 2.737 15.102 7.705 20.958 l 24.728 29.125 l 24.728 -29.125 c 4.969 -5.855 7.706 -13.299 7.706 -20.958 C 77.662 17.67 63.113 3.121 45.229 3.121 z M 45.229 49.801 c -8.499 0 -15.413 -6.915 -15.413 -15.414 s 6.915 -15.414 15.413 -15.414 c 8.499 0 15.413 6.915 15.413 15.414 S 53.728 49.801 45.229 49.801 z M 45.229 21.914 c -6.878 0 -12.473 5.596 -12.473 12.473 s 5.595 12.473 12.473 12.473 s 12.473 -5.596 12.473 -12.473 S 52.106 21.914 45.229 21.914 z"  transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
                        </g>
                    </svg>
                </div>
                <div class="adresy-modal-ingress-block">
                    <span class="adresy-line-1">
                        <?php
                        if (!empty($locations)) {
                            echo 'Delivering to <p>' .  esc_html($line1) . '</p>';
                        } else {
                            echo 'Delivering to <p>' . esc_html($default_location->get_state_name()) . '</p>';
                        }
                        ?>
                    </span>
                    <span class="adresy-line-2">
                        <?php
                        if (!empty($locations)) {
                            echo esc_html($locations);
                        } else {
                            echo esc_html__('Update location', 'adresy');
                        }
                        ?>
                    </span>
                </div>
            </div>
        </div>
<?php

        return ob_get_clean();
    }
}
